"""
Dependencies and configuration settings for the Supervisor Agent.
"""

import os
from functools import lru_cache
from dotenv import load_dotenv, find_dotenv

# Load environment variables from a .env file (looks in current dir and parent dirs)
load_dotenv(find_dotenv())


class Settings:
    """Configuration settings loaded from environment variables with sensible defaults."""

    def __init__(self) -> None:
        self.GROQ_API_KEY: str = os.getenv("GROQ_API_KEY_SUPERVISOR", "")
        self.LLM_MODEL: str = os.getenv("LLM_MODEL", "groq/compound-mini")


@lru_cache
def get_settings() -> Settings:
    """FastAPI dependency to retrieve singleton settings instance."""
    return Settings()
