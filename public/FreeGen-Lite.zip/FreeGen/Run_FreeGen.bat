@echo off
echo =========================================
echo Starting FreeGen (Lite)
echo =========================================

REM Check for python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python is not installed or not in PATH! Please install Python.
    pause
    exit /b
)

REM Setup virtual environment if it doesn't exist
if not exist "backend\.venv" (
    echo [*] Setting up first-time environment. This may take a minute...
    python -m venv backend\.venv
    call backend\.venv\Scripts\activate.bat
    echo [*] Installing dependencies...
    pip install fastapi uvicorn websockets pywebview httpx pydantic openai
) else (
    call backend\.venv\Scripts\activate.bat
)

REM Run the app
echo [*] Launching FreeGen Desktop Interface...
cd backend
python desktop_run.py

pause
