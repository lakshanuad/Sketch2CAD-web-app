@echo off
title FreeGen Lite
cd /d "%~dp0"
if exist backend\.venv\Scripts\python.exe (
    start "" backend\.venv\Scripts\python.exe backend\desktop_run.py
) else (
    python launcher.py || py -3 launcher.py
)
